# 온리비 어서 로컬 플러그인

대화에서 `read_markdown`(읽기), `replace_markdown`(수정),
`list_style_profiles`(서식 조회), `create_style_profile`(신규 서식 생성) 도구를 제공합니다.
Node.js 20 이상에서 로컬로 실행되며 별도의 npm 패키지가 필요하지 않습니다.
기존 `.md` 또는 `.markdown` 파일의 절대경로를 입력하세요. 문서를 먼저 읽고,
수정할 때 반환된 `sha256` 값을 `expectedSha256`으로 전달합니다.
그 사이 파일이 바뀌었다면 저장을 거부합니다.

이 폴더가 플러그인 패키지입니다. Codex에 로컬 플러그인으로 설치한 뒤
플러그인 검색을 다시 실행하거나 앱을 다시 시작하세요. MCP 실행 설정은
`mcp.json`에 있습니다. 온리비 어서 데스크톱 앱은 실행하지 않아도 됩니다.

새 서식은 온리비 어서에 연결된 **로컬 리소스 폴더**의
`profiles/userCssProfiles.json`에 추가됩니다. 먼저 `list_style_profiles`에
리소스 폴더 절대경로를 전달해 서식 ID와 SHA-256을 확인하세요. 이어서
`create_style_profile`에 같은 경로와 SHA-256, 복제할 `baseProfileId`, 새 이름을
전달합니다. `pageStyle`과 `rules`로 일부 속성을 바꿀 수 있습니다. 기존 이름과
중복되거나 조회 뒤 파일이 바뀌면 저장을 거부합니다. Google Drive 리소스
폴더는 이 로컬 MCP 버전에서 지원하지 않습니다.

마크다운 수정 도구는 문서 전체 내용을 교체합니다. 새 마크다운 파일 생성,
폴더 탐색, 파일 뷰어는 지원하지 않습니다.
