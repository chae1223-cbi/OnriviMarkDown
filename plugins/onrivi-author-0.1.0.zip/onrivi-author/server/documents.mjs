import { createHash } from 'node:crypto';
import { promises as fs } from 'node:fs';
import path from 'node:path';

const MAX_BYTES = 2 * 1024 * 1024;
const markdownPath = (value) => typeof value === 'string' && path.isAbsolute(value) && /\.(md|markdown)$/i.test(value);
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');

async function fileAt(input) {
  if (!markdownPath(input)) throw new Error('An absolute .md or .markdown path is required.');
  const resolved = path.resolve(input);
  const stat = await fs.lstat(resolved);
  if (!stat.isFile() || stat.isSymbolicLink()) throw new Error('Only regular Markdown files are supported.');
  if (stat.size > MAX_BYTES) throw new Error('Document exceeds the 2 MiB limit.');
  return resolved;
}

export async function readDocument(input) {
  const file = await fileAt(input);
  const bytes = await fs.readFile(file);
  if (bytes.length > MAX_BYTES || bytes.includes(0)) throw new Error('Only text Markdown files up to 2 MiB are supported.');
  return { path: file, content: bytes.toString('utf8'), sha256: sha256(bytes) };
}

export async function replaceDocument(input, expectedSha256, content) {
  if (typeof content !== 'string') throw new Error('content must be a string.');
  if (!/^[a-f0-9]{64}$/i.test(expectedSha256 ?? '')) throw new Error('A SHA-256 value from read_markdown is required.');
  const bytes = Buffer.from(content, 'utf8');
  if (bytes.length > MAX_BYTES || bytes.includes(0)) throw new Error('Content must be text under 2 MiB.');
  const file = await fileAt(input);
  const handle = await fs.open(file, 'r+');
  try {
    const stat = await handle.stat();
    if (!stat.isFile() || stat.size > MAX_BYTES) throw new Error('Document is no longer a supported file.');
    const current = await handle.readFile();
    if (sha256(current) !== expectedSha256.toLowerCase()) throw new Error('Document changed since it was read. Read it again before saving.');
    // This handle points to the opened file, so swapping its path after validation cannot redirect the write.
    await handle.truncate(0);
    await handle.write(bytes, 0, bytes.length, 0);
    await handle.sync();
  } finally {
    await handle.close();
  }
  return { path: file, sha256: sha256(bytes), bytes: bytes.length };
}
