# Onrivi Author local plugin

This first version exposes two conversation tools: `read_markdown` and `replace_markdown`.
It runs locally with Node.js 20 or newer and needs no npm dependencies. Use absolute
paths to existing `.md` or `.markdown` files. Read first, then pass the returned
`sha256` as `expectedSha256` when replacing the document. A changed file is rejected.

The plugin package is this directory. Install it as a local plugin in Codex,
then restart or reload plugin discovery. The MCP process is defined in `mcp.json`.
It does not require the Electron application to be running.

This first version replaces full document content. It does not create files,
list folders, or register a file viewer. Keep a copy or use version control for
important documents before bulk edits.
