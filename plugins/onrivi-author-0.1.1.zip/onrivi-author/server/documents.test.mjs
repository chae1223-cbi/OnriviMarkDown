import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { test } from 'node:test';
import { readDocument, replaceDocument } from './documents.mjs';

test('reads and replaces Markdown while rejecting a stale revision', async () => {
  const dir = await mkdtemp(path.join(tmpdir(), 'onrivi-mcp-'));
  const file = path.join(dir, 'note.md');
  try {
    await writeFile(file, '# First\n', 'utf8');
    const first = await readDocument(file);
    assert.equal(first.content, '# First\n');
    const saved = await replaceDocument(file, first.sha256, '# 두 번째\n');
    assert.equal((await readFile(file, 'utf8')), '# 두 번째\n');
    assert.notEqual(saved.sha256, first.sha256);
    await assert.rejects(replaceDocument(file, first.sha256, 'stale'), /파일이 변경되었습니다/);
    assert.equal((await readFile(file, 'utf8')), '# 두 번째\n');
    await assert.rejects(readDocument(path.join(dir, 'note.txt')), /절대경로/);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});
