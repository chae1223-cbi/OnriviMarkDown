import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';

test('MCP initializes and discovers both tools', async () => {
  const child = spawn(process.execPath, [fileURLToPath(new URL('./index.mjs', import.meta.url))], { stdio: ['pipe', 'pipe', 'pipe'] });
  try {
    const lines = [];
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', chunk => {
      for (const line of chunk.trim().split('\n')) if (line) lines.push(JSON.parse(line));
    });
    child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-06-18' } }) + '\n');
    child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'tools/list' }) + '\n');
    child.stdin.end();
    await once(child, 'exit');
    assert.equal(lines[0]?.result?.serverInfo?.name, 'onrivi-author-local');
    assert.deepEqual(lines[1]?.result?.tools?.map(tool => tool.name), ['read_markdown', 'replace_markdown']);
  } finally {
    if (child.exitCode === null) child.kill();
  }
});
